<footer>
   <div class="container">
   	<div class="row">
   		<div class="col-lg-6">

              <p>© 2016 Imenso Software. All rights reserved. </p>
   		 </div>

   		 <div class="col-lg-6" style="text-align: right;">
           
   		 </div>
   	</div>
   </div>


<script type="text/javascript" src="http://code.jquery.com/jquery.min.js"></script>
<script type="text/javascript" src="js/bootstrap.min.js"></script>

    <script src="http://code.jquery.com/jquery-1.7.1.min.js"></script>
    <script src="countdown/jquery.countdown.js"></script>
    <script src="countdown/script.js"></script>


</footer>